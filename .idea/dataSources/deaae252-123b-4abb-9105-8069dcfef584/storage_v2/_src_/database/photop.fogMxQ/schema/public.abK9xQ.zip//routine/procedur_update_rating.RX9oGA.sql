create function procedur_update_rating()
  returns trigger
language plpgsql
as $$
BEGIN
	UPDATE photos
	SET 
		rating = (SELECT avg(rating) FROM ratings WHERE photo_id = new.photo_id),
		number_of_ratings = (SELECT COUNT(*) FROM ratings WHERE photo_id = new.photo_id)
	WHERE
		photo_id = new.photo_id;
	RETURN NEW;
END;
$$;

